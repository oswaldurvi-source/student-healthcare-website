# StudentWell Website Prototype

## How to run
1. Extract `student_healthcare_website.zip`.
2. Open `index.html` in a modern browser.

The website is a responsive front-end prototype. The profile form is a demo only and does not store or transmit information. Dashboard progress values are illustrative.

## Files
- `index.html` — full website, styling, and interactions
- `assets/student-focus-illustration.png` — hero illustration
